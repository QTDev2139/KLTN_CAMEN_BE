<?php

return [
    'tmn_code' => env('VNPAY_TMN_CODE', 'ZIGCWE3V'),
    'hash_secret' => env('VNPAY_HASH_SECRET', 'CWPZ26DKIC1VFQXK5NWGW8MRECDJP8SW'),
    'url' => env('VNPAY_URL', 'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html'),
];