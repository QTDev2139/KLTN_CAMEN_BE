<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;


class User extends Authenticatable implements JWTSubject
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'status',
        'role_id'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // Update your User model
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }

    //n User -> 1 Role
    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    //1 User -> n Post
    public function posts(): HasMany
    {
        return $this->hasMany(Post::class, 'user_id');
    }

    //1 User -> 1 Cart
    public function cart(): HasOne
    {
        return $this->hasOne(Cart::class, 'user_id');
    }

    //1 User -> n Coupon
    public function coupons(): HasMany
    {
        return $this->hasMany(Coupon::class, 'user_id');
    }

    //1 User -> n Reviews
    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class, 'user_id');
    }


    // 1 User -> n ChatRooms (as customer or staff)
    public function customerChatRooms(): HasMany
    {
        return $this->hasMany(ChatRoom::class, 'customer_id');
    }

    public function staffChatRooms(): HasMany
    {
        return $this->hasMany(ChatRoom::class, 'staff_id');
    }

    public function chatMessages(): HasMany
    {
        return $this->hasMany(ChatMessage::class, 'sender_id');
    }

    // 1 User -> n Contacts
    public function contacts(): HasMany {
        return $this->hasMany(Contact::class, 'user_id');
    }
}
